"use strict";
(() => {
    const app = document.querySelector("#pos-app");
    if (!app) return;

    const initial = JSON.parse(document.querySelector("#pos-data").textContent);
    const categories = [{ id: "all", name: "Tất cả món" }, ...initial.categories];
    let products = initial.products;
    let visibleProducts = products;
    const productById = new Map(products.map(product => [product.id, product]));
    const state = { category: "all", search: "", discount: 0, discountCode: "", tax: 0,
        orderType: "pickup", payment: "cash", note: "", cart: new Map() };

    // Hỗ trợ chế độ Kiosk tự gọi món
    const urlParams = new URLSearchParams(window.location.search);
    const isKioskMode = urlParams.get("kiosk") === "1" || window.location.pathname.toLowerCase().includes("/kiosk") || !app.dataset.userId;
    const initialMode = urlParams.get("mode");
    const initialPhone = urlParams.get("phone");

    if (initialMode === "dinein" || initialMode === "pickup") {
        state.orderType = initialMode;
    }
    if (isKioskMode) {
        state.tax = 5; // Cố định thuế VAT 5% cho Kiosk
    }
    let vipBadgeText = "";
    if (initialPhone && /^0[0-9]{9}$/.test(initialPhone.trim())) {
        const phone = initialPhone.trim();
        const visitKey = `polykafe_visits_${phone}`;
        let visitCount = Number(localStorage.getItem(visitKey) || 0);

        // Khởi tạo số lần ghé mẫu cho các SĐT test nếu chưa lưu:
        if (!localStorage.getItem(visitKey)) {
            if (["0901234567", "0912345678", "0987654321", "0909090909", "0988888888"].includes(phone)) {
                visitCount = 8; // Khách quen ghé 8 lần -> VVIP
            } else if (["0911223344", "0933445566", "0977889900", "0903456789"].includes(phone)) {
                visitCount = 3; // Khách quen ghé 3 lần -> VIP
            } else {
                visitCount = 1; // Khách mới lần đầu ghé quán
            }
            localStorage.setItem(visitKey, String(visitCount));
        }

        // Tiêu chuẩn phân hạng theo số lần khách ghé quán:
        // - Lần đầu (1 - 2 lần): Khách hàng mới -> Giảm 5%
        // - Từ 3 đến 5 lần: Khách ghé nhiều lần -> Hội viên VIP -> Giảm 10%
        // - Từ 6 lần trở lên: Khách quen thân thiết lâu năm -> Hội viên VVIP -> Giảm 15%
        if (visitCount >= 6) {
            state.discountCode = "SALE15";
            vipBadgeText = "Giảm 15% (Hội viên VVIP)";
        } else if (visitCount >= 3) {
            state.discountCode = "SALE10";
            vipBadgeText = "Giảm 10% (Hội viên VIP)";
        } else {
            state.discountCode = "SALE5";
            vipBadgeText = "Giảm 5% (Thành viên mới)";
        }
    } else {
        // Khách vãng lai: BỎ LUÔN dòng ưu đãi, không hiển thị bất kỳ thông báo nào
        state.discountCode = "";
        vipBadgeText = "";
    }

    const draftKey = `cafepos.pos-draft.${app.dataset.userId}`;
    try {
        const draft = JSON.parse(sessionStorage.getItem(draftKey) || "null");
        sessionStorage.removeItem(draftKey);
        if (draft && Array.isArray(draft.cart)) {
            draft.cart.forEach(([id, quantity]) => {
                if (productById.get(id)?.isAvailable && Number.isInteger(quantity) && quantity > 0 && quantity <= 99)
                    state.cart.set(id, quantity);
            });
            if (categories.some(c => c.id === draft.category)) state.category = draft.category;
            if (typeof draft.search === "string") state.search = draft.search.slice(0, 100);
            if (!initialMode && ["pickup", "dinein"].includes(draft.orderType)) state.orderType = draft.orderType;
            if (["cash", "card", "wallet"].includes(draft.payment)) state.payment = draft.payment;
            if (!initialPhone && typeof draft.note === "string") state.note = draft.note.slice(0, 200);
            if (!initialPhone && initial.discounts.some(d => d.code === draft.discountCode)) state.discountCode = draft.discountCode;
            if (initial.taxRates.includes(draft.tax)) state.tax = draft.tax;
        }
    } catch { /* Trình duyệt chặn sessionStorage: tiếp tục với đơn trống. */ }
    let orderNumber = initial.nextOrderNumber;
    let pendingCheckout = null;
    let checkingOut = false;
    let previewing = false;
    let productRequest = 0;
    let productAbort;
    let searchTimer;
    let lastReceipt = null;
    let editingOrderId = null;
    const money = new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND", maximumFractionDigits: 0 });
    const $ = selector => document.querySelector(selector);
    const grid = $("#product-grid");
    const cartItems = $("#cart-items");
    const status = $("#pos-status");
    $("#product-search").value = state.search;
    $("#discount").value = state.discountCode;
    state.discount = initial.discounts.find(d => d.code === state.discountCode)?.percent || 0;
    $("#tax-percent").value = String(state.tax);
    $("#order-note").value = state.note;
    $("input[name=payment][value=" + state.payment + "]").checked = true;
    $("#order-types")?.querySelectorAll("button").forEach(button => {
        button.classList.toggle("active", button.dataset.order === state.orderType);
        button.setAttribute("aria-pressed", String(button.dataset.order === state.orderType));
    });
    const backKioskBtn = $("#btn-back-kiosk-toolbar");
    if (backKioskBtn && !isKioskMode) {
        backKioskBtn.style.display = "none";
    }
    const orderTypeField = $("#order-type-field");
    const discountField = $("#discount-field");
    const vipBadge = $("#vip-member-badge");
    const noteField = $("#note-field");

    if (isKioskMode) {
        if (orderTypeField) orderTypeField.style.display = "none";
        if (vipBadgeText) {
            if (discountField) discountField.style.display = "block";
            if (vipBadge) {
                vipBadge.textContent = vipBadgeText;
                vipBadge.hidden = false;
            }
            const discountSelect = $("#discount");
            if (discountSelect) {
                discountSelect.style.display = "none";
                discountSelect.disabled = true;
            }
            const discountLabel = $("#discount-label-title");
            if (discountLabel) discountLabel.textContent = "Ưu đãi thành viên";
        } else {
            // Khách vãng lai: ẩn hoàn toàn ô ưu đãi, không hiển thị gì cả
            if (discountField) discountField.style.display = "none";
            if (vipBadge) vipBadge.hidden = true;
            if (noteField) noteField.classList.add("full-width");
        }
    } else {
        if (vipBadge) vipBadge.hidden = true;
    }
    const taxSelect = $("#tax-percent");
    if (taxSelect && isKioskMode) {
        taxSelect.value = "5";
        state.tax = 5;
        taxSelect.disabled = true;
        taxSelect.style.display = "none";
        const taxLabel = $("#tax-fixed-label");
        if (taxLabel) taxLabel.hidden = false;
    }
    let notificationTimer;

    function notify(message) {
        window.clearTimeout(notificationTimer);
        status.textContent = message;
        notificationTimer = window.setTimeout(() => { status.textContent = ""; }, 3500);
    }

    function totals() {
        let subtotal = 0;
        let count = 0;
        state.cart.forEach((quantity, id) => { subtotal += productById.get(id).price * quantity; count += quantity; });
        const discount = Math.round(subtotal * state.discount / 100);
        const tax = Math.round((subtotal - discount) * state.tax / 100);
        return { subtotal, discount, tax, total: subtotal - discount + tax, count };
    }

    function setImage(image, product) {
        image.alt = image.classList.contains("cart-thumbnail") ? "" : product.name;
        image.src = product.imageUrl;
    }

    // error không bubble; capture xử lý cả ảnh mới render, không lặp khi ảnh dự phòng lỗi.
    app.addEventListener("error", event => {
        const image = event.target;
        if (!(image instanceof HTMLImageElement) || image.dataset.fallback) return;
        image.dataset.fallback = "true";
        image.src = app.dataset.fallbackImage;
    }, true);

    function renderCategories() {
        const fragment = document.createDocumentFragment();
        categories.forEach(category => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "category-button";
            button.dataset.category = category.id;
            button.setAttribute("aria-pressed", String(category.id === state.category));
            button.classList.toggle("active", category.id === state.category);
            const label = document.createElement("span");
            label.className = "category-label";
            label.textContent = category.name;
            const count = document.createElement("span");
            count.className = "category-count";
            count.textContent = String(category.id === "all" ? products.length : products.filter(product => product.categoryId === category.id).length);
            const arrow = document.createElementNS("http://www.w3.org/2000/svg", "svg");
            arrow.classList.add("icon");
            arrow.setAttribute("aria-hidden", "true");
            const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
            use.setAttribute("href", "#i-arrow");
            arrow.append(use);
            button.append(label, count, arrow);
            fragment.append(button);
        });
        $("#category-list").replaceChildren(fragment);
        const categorySelect = $("#new-category");
        if (categorySelect) {
            categorySelect.replaceChildren();
            categories.filter(category => category.id !== "all").forEach(category => {
                const option = new Option(category.name, category.id);
                categorySelect.add(option);
            });
        }
    }

    function renderProducts() {
        const visible = visibleProducts;
        const fragment = document.createDocumentFragment();
        visible.forEach(product => {
            const card = $("#product-template").content.firstElementChild.cloneNode(true);
            card.dataset.product = product.id;
            card.disabled = !product.isAvailable || Boolean(pendingCheckout) || previewing;
            if (!product.isAvailable) card.title = "Món đang ngừng bán";
            card.setAttribute("aria-label", `Thêm ${product.name}, ${money.format(product.price)} vào giỏ`);
            setImage(card.querySelector("img"), product);
            card.querySelector(".product-name").textContent = product.name + (product.isAvailable ? "" : " · Ngừng bán");
            card.querySelector(".product-name").title = product.name;
            card.querySelector(".product-prices del").textContent = product.originalPrice ? money.format(product.originalPrice) : "";
            card.querySelector(".product-prices strong").textContent = money.format(product.price);
            fragment.append(card);
        });
        grid.replaceChildren(fragment);
        grid.setAttribute("aria-busy", "false");
        $("#product-count").textContent = `${visible.length} món`;
        $("#menu-title").textContent = categories.find(category => category.id === state.category).name;
        $("#no-results").hidden = visible.length > 0;
        const loadError = $("#load-error");
        if (loadError) loadError.hidden = true;
        updateSelectedProducts();
    }

    function updateSelectedProducts() {
        grid.querySelectorAll("[data-product]").forEach(card => {
            const quantity = state.cart.get(card.dataset.product) || 0;
            card.disabled = !productById.get(card.dataset.product).isAvailable || Boolean(pendingCheckout) || previewing;
            card.classList.toggle("selected", quantity > 0);
            card.querySelector(".product-add").textContent = quantity > 0 ? String(quantity) : "+";
        });
    }

    let lastRenderedTotal = null;

    function renderCart() {
        const focused = document.activeElement;
        const focusedProduct = focused?.closest(".cart-item")?.dataset.product;
        const focusedAction = focused?.dataset.action;
        const fragment = document.createDocumentFragment();
        state.cart.forEach((quantity, id) => {
            const product = productById.get(id);
            const row = $("#cart-template").content.firstElementChild.cloneNode(true);
            row.dataset.product = id;
            setImage(row.querySelector("img"), product);
            row.querySelector("h3").textContent = product.name;
            row.querySelector(".cart-unit-price").textContent = money.format(product.price);
            row.querySelector(".quantity").textContent = String(quantity);
            row.querySelector(".line-total").textContent = money.format(product.price * quantity);
            const decrease = row.querySelector('[data-action="decrease"]');
            const increase = row.querySelector('[data-action="increase"]');
            decrease.disabled = Boolean(pendingCheckout) || previewing;
            increase.disabled = quantity >= 99 || Boolean(pendingCheckout) || previewing;
            row.querySelector('[data-action="remove"]').disabled = Boolean(pendingCheckout) || previewing;
            decrease.setAttribute("aria-label", `Giảm số lượng ${product.name}`);
            increase.setAttribute("aria-label", `Tăng số lượng ${product.name}`);
            row.querySelector('[data-action="remove"]').setAttribute("aria-label", `Xóa ${product.name}`);
            fragment.append(row);
        });
        cartItems.replaceChildren(fragment);
        const amount = totals();
        $("#cart-empty").hidden = amount.count > 0;
        $("#cart-count").textContent = String(amount.count);
        $("#subtotal").textContent = money.format(amount.subtotal);
        const totalEl = $("#total");
        if (lastRenderedTotal !== null && lastRenderedTotal !== amount.total && totalEl) {
            totalEl.classList.remove("total-pulsing");
            void totalEl.offsetWidth;
            totalEl.classList.add("total-pulsing");
        }
        lastRenderedTotal = amount.total;
        $("#total").textContent = money.format(amount.total);
        $("#mobile-total").textContent = money.format(amount.total);
        $("#discount-row").hidden = !state.discount;
        $("#discount-label").textContent = `Giảm giá (${state.discount}%)`;
        $("#discount-amount").textContent = `−${money.format(amount.discount)}`;
        $("#tax-amount").textContent = money.format(amount.tax);
        $("#checkout").disabled = checkingOut || previewing || (!amount.count && !pendingCheckout);
        $("#checkout").textContent = checkingOut ? (editingOrderId ? "Đang cập nhật đơn..." : "Đang ghi nhận đơn...")
            : pendingCheckout ? "Thử xác nhận lại" : editingOrderId ? `Cập nhật đơn ${lastReceipt?.orderNumber || ""}` : "Ghi nhận đơn";
        $("#print-receipt").disabled = Boolean(pendingCheckout) || previewing || (!amount.count && !lastReceipt);
        if ($("#clear-cart")) $("#clear-cart").disabled = Boolean(pendingCheckout) || previewing;
        $("#pos-app").querySelectorAll("#order-types button:not([data-not-integrated]), #discount, #tax-percent, #order-note, input[name=payment]:not([data-not-integrated])").forEach(el => { el.disabled = Boolean(pendingCheckout) || previewing; });
        updateSelectedProducts();
        if (focusedProduct && focusedAction) {
            const row = cartItems.querySelector(`[data-product="${focusedProduct}"]`);
            const target = row?.querySelector(`[data-action="${focusedAction}"]:not(:disabled)`) || row?.querySelector("button:not(:disabled)") || cartItems.querySelector("button:not(:disabled)");
            (target || $("#product-search")).focus({ preventScroll: true });
        }
    }

    $("#category-list").addEventListener("click", event => {
        const button = event.target.closest("[data-category]");
        if (!button) return;
        state.category = button.dataset.category;
        $("#category-list").querySelectorAll("button").forEach(item => {
            item.classList.toggle("active", item === button);
            item.setAttribute("aria-pressed", String(item === button));
        });
        loadProducts();
        $("#product-scroll").scrollTop = 0;
    });
    $("#product-search").addEventListener("input", event => { state.search = event.target.value; window.clearTimeout(searchTimer); searchTimer = window.setTimeout(loadProducts, 180); });
    $("#reset-search").addEventListener("click", () => {
        state.search = "";
        $("#product-search").value = "";
        $("#category-list [data-category='all']").click();
        $("#product-search").focus();
    });
    $("#retry-load")?.addEventListener("click", () => loadProducts(true));
    grid.addEventListener("click", event => {
        const card = event.target.closest("[data-product]");
        if (pendingCheckout || previewing || !card || !productById.get(card.dataset.product)?.isAvailable) return;
        const id = card.dataset.product;
        const quantity = state.cart.get(id) || 0;
        if (!quantity && state.cart.size >= 100) { notify("Mỗi đơn tối đa 100 món khác nhau."); return; }
        if (quantity >= 99) { notify("Mỗi món tối đa 99 phần trong một đơn."); return; }
        state.cart.set(id, quantity + 1);
        renderCart();
        notify(`Đã thêm ${productById.get(id).name} vào giỏ.`);
    });
    cartItems.addEventListener("click", event => {
        const button = event.target.closest("[data-action]");
        const id = button?.closest("[data-product]")?.dataset.product;
        if (pendingCheckout || previewing || !button || !state.cart.has(id)) return;
        const quantity = state.cart.get(id);
        if (button.dataset.action === "remove") state.cart.delete(id);
        else if (button.dataset.action === "increase" && quantity < 99) state.cart.set(id, quantity + 1);
        else if (button.dataset.action === "decrease") { if (quantity === 1) state.cart.delete(id); else state.cart.set(id, quantity - 1); }
        renderCart();
    });
    $("#order-types")?.addEventListener("click", event => {
        const button = event.target.closest("[data-order]");
        if (!button || button.disabled) return;
        state.orderType = button.dataset.order;
        $("#order-types")?.querySelectorAll("button").forEach(item => {
            item.classList.toggle("active", item === button);
            item.setAttribute("aria-pressed", String(item === button));
        });
    });
    $("#discount").addEventListener("change", event => {
        state.discountCode = event.target.value;
        state.discount = initial.discounts.find(d => d.code === state.discountCode)?.percent || 0;
        renderCart();
    });
    $("#tax-percent").addEventListener("change", event => { state.tax = Number(event.target.value); renderCart(); });
    $("#order-note").addEventListener("input", event => { state.note = event.target.value.slice(0, 200); });
    $("#payment-options").addEventListener("change", event => {
        if (event.target.disabled) return;
        if (["cash", "card", "wallet"].includes(event.target.value)) state.payment = event.target.value;
    });
    $("#clear-cart")?.addEventListener("click", () => bootstrap.Modal.getOrCreateInstance($("#clear-modal")).show());
    $("#confirm-clear")?.addEventListener("click", () => {
        if (pendingCheckout || previewing) return;
        resetOrder();
        bootstrap.Modal.getInstance($("#clear-modal")).hide();
        notify("Đã xóa giỏ và đặt lại cấu hình đơn.");
    });
    $("#refresh-pos").addEventListener("click", () => loadProducts(true));
    let loggingOut = false;
    let navigatingToManager = false;
    $("#pos-logout")?.addEventListener("submit", () => {
        loggingOut = true;
        try { sessionStorage.removeItem(draftKey); } catch { /* Không có draft cần xóa. */ }
    });
    document.querySelectorAll("[data-manage-link]").forEach(link => link.addEventListener("click", event => {
        if (pendingCheckout) { event.preventDefault(); notify("Đơn đang chờ xác nhận. Hãy hoàn tất hoặc thử lại trước khi chuyển trang."); return; }
        try {
            sessionStorage.setItem(draftKey, JSON.stringify({ ...state, cart: [...state.cart] }));
            navigatingToManager = true;
        } catch {
            if (state.cart.size) { event.preventDefault(); notify("Không thể giữ đơn đang lập khi chuyển trang. Hãy hoàn tất đơn trước."); }
        }
    }));

    async function request(url, data, signal, method = (data ? "POST" : "GET")) {
        const controller = new AbortController();
        const abort = () => controller.abort();
        signal?.addEventListener("abort", abort, { once: true });
        if (signal?.aborted) abort();
        const timeoutId = window.setTimeout(abort, 20000);
        try {
            const response = await fetch(url, { method, signal: controller.signal,
                headers: data ? { "Content-Type": "application/json", "X-CSRF-TOKEN": $("input[name=__RequestVerificationToken]").value } : {},
                body: data ? JSON.stringify(data) : undefined });
            const result = await response.json().catch(() => null);
            if (!response.ok) {
                const error = new Error(result?.errors?.join(" ") || result?.message || "Yêu cầu không thành công. Vui lòng tải lại trang nếu phiên đã hết hạn.");
                // Chỉ lỗi từ chối đầu vào chắc chắn chưa ghi nhận đơn. Lỗi 5xx cần thử lại cùng RequestId.
                error.rejected = response.status >= 400 && response.status < 500;
                throw error;
            }
            if (!result) throw new Error("Không đọc được phản hồi máy chủ. Vui lòng thử lại.");
            return result;
        } catch (error) {
            if (signal?.aborted) throw error;
            if (error.name === "AbortError" || error instanceof TypeError)
                throw new Error("Không kết nối được máy chủ hoặc đã quá thời gian chờ. Vui lòng thử lại.");
            throw error;
        } finally {
            window.clearTimeout(timeoutId);
            signal?.removeEventListener("abort", abort);
        }
    }

    async function loadProducts(refreshAll = false) {
        const requestId = ++productRequest;
        productAbort?.abort();
        productAbort = new AbortController();
        grid.setAttribute("aria-busy", "true");
        $("#product-count").textContent = "Đang tải...";
        const loadError = $("#load-error");
        if (loadError) loadError.hidden = true;
        if (refreshAll || !grid.children.length) {
            const fragment = document.createDocumentFragment();
            for (let i = 0; i < 6; i++) {
                const sk = document.createElement("div");
                sk.className = "skeleton-card";
                sk.setAttribute("aria-hidden", "true");
                sk.innerHTML = '<div class="skeleton-image skeleton"></div><div class="skeleton-info"><div class="skeleton skeleton-text" style="width: 80%; height: 14px; margin-bottom: 8px;"></div><div class="skeleton skeleton-text" style="width: 45%; height: 16px;"></div></div>';
                fragment.append(sk);
            }
            grid.replaceChildren(fragment);
        }
        try {
            if (refreshAll) {
                const all = await request(app.dataset.productsUrl, null, productAbort.signal);
                if (requestId !== productRequest) return;
                products = all;
                all.forEach(p => productById.set(p.id, p));
                renderCategories();
            }
            const url = new URL(app.dataset.productsUrl, location.href);
            if (state.category !== "all") url.searchParams.set("categoryId", state.category);
            url.searchParams.set("search", state.search);
            const found = await request(url, null, productAbort.signal);
            if (requestId !== productRequest) return;
            visibleProducts = found;
            found.forEach(p => productById.set(p.id, p));
            if (loadError) loadError.hidden = true;
            renderProducts();
            renderCart();
        } catch (error) {
            if (error.name === "AbortError" || requestId !== productRequest) return;
            visibleProducts = [];
            grid.replaceChildren();
            $("#no-results").hidden = true;
            if (loadError) loadError.hidden = false;
            $("#product-count").textContent = "Không tải được · Bấm Thử tải lại";
            notify(error.message);
        } finally { if (requestId === productRequest) grid.setAttribute("aria-busy", "false"); }
    }

    function generateUuid() {
        if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
            try { return crypto.randomUUID(); } catch { /* fallback bên dưới */ }
        }
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
            const r = Math.random() * 16 | 0;
            const v = c === "x" ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    function orderPayload() {
        let userNote = ($("#order-note")?.value || state.note || "").trim();
        let finalNote = userNote;
        if (initialPhone && /^0[0-9]{9}$/.test(initialPhone.trim())) {
            const p = initialPhone.trim();
            finalNote = userNote ? `${userNote} (SĐT: ${p})` : `SĐT: ${p}`;
        }
        return { requestId: generateUuid(), orderType: state.orderType, paymentMethod: state.payment,
            discountCode: state.discountCode || null, taxPercent: state.tax, note: finalNote,
            items: [...state.cart].map(([productId, quantity]) => ({ productId, quantity })) };
    }

    function resetOrder() {
        state.cart.clear();
        editingOrderId = null;
        if (!initialPhone) {
            state.discount = 0;
            state.discountCode = "";
        }
        state.note = "";
        state.payment = "cash";
        if (initialMode) {
            state.orderType = initialMode;
        } else {
            state.orderType = "pickup";
        }
        if (!isKioskMode) {
            $("#discount").value = "";
            $("#tax-percent").value = "0";
            state.tax = 0;
        } else {
            state.tax = 5;
        }
        $("#order-note").value = "";
        $("input[name=payment][value=cash]").checked = true;
        $("#order-types")?.querySelectorAll("button").forEach(button => {
            button.classList.toggle("active", button.dataset.order === state.orderType);
            button.setAttribute("aria-pressed", String(button.dataset.order === state.orderType));
        });
        renderCart();
    }

    function showReceipt(order, committed) {
        const orderNames = { pickup: "Mang đi", delivery: "Giao hàng", dinein: "Tại bàn" };
        const paymentNames = { cash: "Tiền mặt", card: "Thẻ ngân hàng", wallet: "Ví điện tử" };
        const date = new Intl.DateTimeFormat("vi-VN", { dateStyle: "short", timeStyle: "short", timeZone: "Asia/Ho_Chi_Minh" }).format(new Date(order.createdAt));
        $("#receipt-title").textContent = committed ? "Đơn đã ghi nhận" : "Hóa đơn tạm tính";
        $(".receipt-watermark").textContent = committed ? "ĐÃ GHI NHẬN ĐƠN NỘI BỘ" : "TẠM TÍNH · CHƯA CHỐT ĐƠN";
        $("#receipt-meta").textContent = `Đơn ${order.orderNumber} · ${date} · ${orderNames[order.orderType]} · ${paymentNames[order.paymentMethod]}`;
        const fragment = document.createDocumentFragment();
        order.items.forEach(item => {
            const row = document.createElement("div"); row.className = "receipt-line";
            const label = document.createElement("span");
            label.textContent = `${item.quantity} × ${item.productName} (${money.format(item.unitPrice)})`;
            const value = document.createElement("strong"); value.textContent = money.format(item.lineTotal);
            row.append(label, value); fragment.append(row);
        });
        $("#receipt-lines").replaceChildren(fragment);
        const summary = document.createDocumentFragment();
        [["Tạm tính", order.subtotal], [`Giảm giá (${order.discountPercent}%)`, -order.discountAmount],
            [`Thuế VAT (${order.taxPercent}%)`, order.taxAmount], ["Tổng cộng", order.total]].forEach(([label, value], index) => {
            const row = document.createElement("div"); if (index === 3) row.className = "total-row";
            const term = document.createElement("dt"); term.textContent = label;
            const description = document.createElement("dd"); description.textContent = money.format(value);
            row.append(term, description); summary.append(row);
        });
        $("#receipt-summary").replaceChildren(summary);
        $("#receipt-note").textContent = order.note ? `Ghi chú: ${order.note}` : "";
        // Hiện nút "Sửa / Thêm món" chỉ khi đơn đã ghi nhận (committed)
        const editBtn = $("#edit-last-order");
        if (editBtn) {
            editBtn.style.display = committed ? "" : "none";
        }
        const kioskReturnBtn = $("#kiosk-modal-return-btn");
        if (kioskReturnBtn) {
            if (isKioskMode && committed) {
                kioskReturnBtn.style.display = "";
                let countdown = 12;
                const cdSpan = $("#kiosk-countdown");
                if (cdSpan) cdSpan.textContent = String(countdown);
                const timer = setInterval(() => {
                    countdown--;
                    if (cdSpan) cdSpan.textContent = String(countdown);
                    if (countdown <= 0) {
                        clearInterval(timer);
                        window.location.href = "/Kiosk";
                    }
                }, 1000);
            } else {
                kioskReturnBtn.style.display = "none";
            }
        }
        bootstrap.Modal.getOrCreateInstance($("#receipt-modal")).show();
    }

    $("#checkout").addEventListener("click", async () => {
        if (checkingOut || previewing) return;
        if (!state.cart.size) { notify("Giỏ hàng trống. Vui lòng chọn món trước khi thanh toán."); return; }
        pendingCheckout ||= orderPayload();
        checkingOut = true; renderCart();
        try {
            const result = editingOrderId
                ? await request(`${app.dataset.updateUrl}?id=${editingOrderId}`, pendingCheckout, undefined, "PUT")
                : await request(app.dataset.checkoutUrl, pendingCheckout);
            const wasEditing = Boolean(editingOrderId);
            lastReceipt = result.order;
            orderNumber = result.nextOrderNumber;
            $("#order-number").textContent = `Đơn ${orderNumber}`;
            pendingCheckout = null;
            // Tự động tăng số lần ghé quán cho SĐT khi đặt đơn thành công
            if (initialPhone && /^0[0-9]{9}$/.test(initialPhone.trim())) {
                const p = initialPhone.trim();
                const vk = `polykafe_visits_${p}`;
                const currentVisits = Number(localStorage.getItem(vk) || 1);
                localStorage.setItem(vk, String(currentVisits + 1));
            }
            resetOrder();
            showReceipt(lastReceipt, true);
            notify(wasEditing ? `Đã cập nhật đơn ${lastReceipt.orderNumber}.` : `Đã ghi nhận đơn ${lastReceipt.orderNumber}.`);
        } catch (error) {
            if (error.rejected) pendingCheckout = null;
            notify(pendingCheckout ? "Chưa xác nhận được kết quả. Giữ nguyên trang và bấm Thử xác nhận lại đơn để tránh tạo trùng." : error.message);
        } finally { checkingOut = false; renderCart(); }
    });
    $("#print-receipt").addEventListener("click", async () => {
        if (pendingCheckout || previewing) return;
        if (!state.cart.size) { if (lastReceipt) showReceipt(lastReceipt, true); return; }
        previewing = true; renderCart();
        try { showReceipt(await request(app.dataset.previewUrl, orderPayload()), false); }
        catch (error) { notify(error.message); }
        finally { previewing = false; renderCart(); }
    });
    $("#print-preview").addEventListener("click", () => window.print());
    window.addEventListener("beforeunload", event => {
        if (!loggingOut && !navigatingToManager && (pendingCheckout || state.cart.size)) { event.preventDefault(); event.returnValue = ""; }
    });

    $("#add-product-form")?.addEventListener("submit", async event => {
        event.preventDefault();
        const button = $("#save-product");
        if (button.disabled) return;
        const errorBox = $("#product-error"); errorBox.hidden = true;
        const payload = { name: $("#new-name").value.trim(), categoryId: $("#new-category").value,
            price: Number($("#new-price").value), originalPrice: $("#new-original-price").value === "" ? null : Number($("#new-original-price").value),
            imageUrl: $("#new-image").value.trim() || null, isAvailable: $("#new-available").checked };
        if (!payload.name) { errorBox.textContent = "Vui lòng nhập tên món."; errorBox.hidden = false; return; }
        button.disabled = true; button.textContent = "Đang lưu...";
        try {
            const product = await request(app.dataset.createUrl, payload);
            products.push(product); productById.set(product.id, product);
            state.category = product.categoryId; state.search = ""; $("#product-search").value = "";
            renderCategories();
            event.target.reset();
            bootstrap.Modal.getOrCreateInstance($("#add-product-modal")).hide();
            await loadProducts(); notify("Đã thêm món mới vào thực đơn.");
        } catch (error) { errorBox.textContent = error.message; errorBox.hidden = false; }
        finally { button.disabled = false; button.textContent = "Lưu món"; }
    });
    $("#calculator-form").addEventListener("submit", event => {
        event.preventDefault();
        const first = Number($("#calc-a").value);
        const second = Number($("#calc-b").value);
        const operation = $("#calc-operation").value;
        const output = $("#calc-result");
        if (!Number.isFinite(first) || !Number.isFinite(second) || Math.abs(first) > 1e12 || Math.abs(second) > 1e12) { output.textContent = "Vui lòng nhập số hữu hạn có trị tuyệt đối không quá 1.000.000.000.000."; return; }
        if (operation === "divide" && second === 0) { output.textContent = "Không thể chia cho 0."; return; }
        const result = { add: () => first + second, subtract: () => first - second, multiply: () => first * second, divide: () => first / second }[operation]?.();
        output.textContent = Number.isFinite(result) ? `Kết quả: ${new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 8 }).format(result)}` : "Không thể tính kết quả.";
    });
    // === SỬA / BỔ SUNG MÓN CHO ĐƠN VỪA GHI NHẬN ===
    const editLastOrderBtn = $("#edit-last-order");
    if (editLastOrderBtn) {
        editLastOrderBtn.addEventListener("click", () => {
            if (!lastReceipt?.id || !Array.isArray(lastReceipt.items) || !lastReceipt.items.length) {
                notify("Không tìm thấy đơn hàng vừa ghi nhận.");
                return;
            }
            state.cart.clear();
            let skipped = 0;
            lastReceipt.items.forEach(item => {
                const product = productById.get(item.productId);
                if (product?.isAvailable && Number.isInteger(item.quantity) && item.quantity > 0 && item.quantity <= 99)
                    state.cart.set(item.productId, item.quantity);
                else skipped++;
            });
            editingOrderId = lastReceipt.id;
            $("#order-number").textContent = `Đang sửa ${lastReceipt.orderNumber}`;
            state.orderType = lastReceipt.orderType || "pickup";
            state.payment = lastReceipt.paymentMethod || "cash";
            state.note = lastReceipt.note || "";
            state.tax = Number(lastReceipt.taxPercent || 0);
            state.discount = Number(lastReceipt.discountPercent || 0);
            state.discountCode = initial.discounts.find(d => Number(d.percent) === state.discount)?.code || "";
            $("#discount").value = state.discountCode;
            $("#tax-percent").value = String(state.tax);
            $("#order-note").value = state.note;
            $("input[name=payment][value=" + state.payment + "]").checked = true;
            $("#order-types")?.querySelectorAll("button").forEach(button => {
                button.classList.toggle("active", button.dataset.order === state.orderType);
                button.setAttribute("aria-pressed", String(button.dataset.order === state.orderType));
            });
            renderCart();
            bootstrap.Modal.getInstance($("#receipt-modal"))?.hide();
            notify(skipped ? `Đã nạp đơn ${lastReceipt.orderNumber}; bỏ qua ${skipped} món không còn kinh doanh.`
                : `Đang chỉnh sửa đơn ${lastReceipt.orderNumber}. Bấm Cập nhật đơn để lưu thay đổi.`);
        });
    }
    renderCategories();
    renderProducts();
    renderCart();
    if (state.category !== "all" || state.search) loadProducts();
})();
